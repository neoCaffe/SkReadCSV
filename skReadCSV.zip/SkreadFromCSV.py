"""
=========================================================
K-means Clustering
=========================================================
original source code comes from Sklearn web site
"""
import numpy as np
import matplotlib.pyplot as plt
# Though the following import is not directly being used, it is required
# for 3D projection to work
from mpl_toolkits.mplot3d import Axes3D
from sklearn.cluster import KMeans
from sklearn import datasets

np.random.seed(5)
#--- 讀取資料 datasets.load_iris() --------------------
'''
iris = datasets.load_iris()
X = iris.data
y = iris.target
print(f'type(iris)  {type(iris)}  shape: {iris.data.shape}')
print(type(X))
print(X.shape)
print(X[0,:])                # float64
print(X[0,:].dtype)
print(y.dtype)               # int32
'''
#--- modified part 
#--- 讀取自定的 irisC.csv
iris = np.genfromtxt("irisC.csv",delimiter=',',dtype=np.float64) 
r,c  = iris.shape
print(f'row: {r} columns: {c}')                # row 0 is header
X = iris[1:,0:4]          # X.dtype float64 
#print(X[0,:])            # X 0~3 column contents
y = iris[1:,4]
y = np.array(y,dtype= np.int32)
print(f'target type : {y[:].dtype}')         # y.dtype int32

#--- 載入欄位名稱 ------
#--- 問題是 np 已設定為 dtype float64 ，所以header讀出來是 nan 無法使用
#--- 所以重新再讀一次，使用 Unicode string type 'U'
#--- 此處只是讀出欄位名稱，並未使用它
irisH = np.genfromtxt('irisC.csv',delimiter=',',dtype='U')
fld = []
# 首列是欄位名稱
for n in range(0,5):
    fld.append(irisH[0,n])
    
print('欄位名稱 :',fld)
#-------------------------------------
#---  back to the Example codes ------------------- 
estimators = [('k_means_iris_8', KMeans(n_clusters=8)),
              ('k_means_iris_3', KMeans(n_clusters=3)),
              ('k_means_iris_bad_init', KMeans(n_clusters=3, n_init=1,
                                               init='random'))]

fignum = 1
titles = ['8 clusters', '3 clusters', '3 clusters, bad initialization']
for name, est in estimators:
    fig = plt.figure(fignum, figsize=(4, 3))
    ax = Axes3D(fig, rect=[0, 0, .95, 1], elev=48, azim=134)
    est.fit(X)
    labels = est.labels_

    ax.scatter(X[:, 3], X[:, 0], X[:, 2],
               c=labels.astype(float), edgecolor='k')

    ax.w_xaxis.set_ticklabels([])
    ax.w_yaxis.set_ticklabels([])
    ax.w_zaxis.set_ticklabels([])
    ax.set_xlabel('Petal width')
    ax.set_ylabel('Sepal length')
    ax.set_zlabel('Petal length')
    ax.set_title(titles[fignum - 1])
    ax.dist = 12
    fignum = fignum + 1

# Plot the ground truth
fig = plt.figure(fignum, figsize=(4, 3))
ax = Axes3D(fig, rect=[0, 0, .95, 1], elev=48, azim=134)

for name, label in [('Setosa', 0),
                    ('Versicolour', 1),
                    ('Virginica', 2)]:
    ax.text3D(X[y == label, 3].mean(),
              X[y == label, 0].mean(),
              X[y == label, 2].mean() + 2, name,
              horizontalalignment='center',
              bbox=dict(alpha=.2, edgecolor='w', facecolor='w'))

# Reorder the labels to have colors matching the cluster results
y = np.choose(y, [1, 2, 0]).astype(float)
ax.scatter(X[:, 3], X[:, 0], X[:, 2], c=y, edgecolor='k')

ax.w_xaxis.set_ticklabels([])
ax.w_yaxis.set_ticklabels([])
ax.w_zaxis.set_ticklabels([])
ax.set_xlabel('Petal width')
ax.set_ylabel('Sepal length')
ax.set_zlabel('Petal length')
ax.set_title('Ground Truth')
ax.dist = 12

#fig.show()
